Acid Shaders by MiningGodBruce
[https://www.minecraftforum.net/forums/mapping-and-modding-java-edition/minecraft-mods/1292876-glsl-acid-shaders](https://www.minecraftforum.net/forums/mapping-and-modding-java-edition/minecraft-mods/1292876-glsl-acid-shaders)

Original Acid shaders by Gaeel
[https://pastebin.com/WbVNtMg7](https://pastebin.com/WbVNtMg7)

Creating the GLSL shaders mod: Daxnitro 
Maintaining the GLSL shaders mod: Karyonix

Remaster by TwentySeven

--------------------------------------------------
If you want to create custom functions, go to common.glsl to learn how.
--------------------------------------------------
Thank you for using my shaders! The base shaders are a heavily modified [https://modrinth.com/shader/base-shader](https://modrinth.com/shader/base-shader) to be basically exactly like acid shaders!

I just thought adding my own functions and making the editing process easy would
be a nice little upgrade. I have loved acid shaders since 2016, and have always wanted to learn how to make something similar.

5 years later (2021), I actualy looked inside the shader, and realized it was way easier than I thought it was.
I tried to make something, but never got far with it.

But now, (Late 2024), I actually know what I am doing. I know GLSL, I know how to utilize a workflow, I know what I have to do.
I have to make Acid Shaders fully user friendly.
