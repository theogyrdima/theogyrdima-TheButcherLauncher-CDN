#version 120
#include "common.glsl"





varying vec4 color;
varying vec4 texcoord;
varying vec4 lmcoord;


void main()
{
	vec4 position = gl_ModelViewMatrix * gl_Vertex;
	
		position = gbufferModelViewInverse * position;

position=geomfunc(position);

		position = gbufferModelView * position;

	gl_Position = gl_ProjectionMatrix * position;
	
	
	gl_FogFragCoord = sqrt(position.x * position.x + position.y * position.y + position.z * position.z);
	
	
	texcoord = gl_TextureMatrix[0] * gl_MultiTexCoord0;
	
	color = gl_Color;
	
	lmcoord = gl_TextureMatrix[1] * gl_MultiTexCoord1;
}