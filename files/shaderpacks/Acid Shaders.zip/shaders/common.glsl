/*
HOW TO USE:
edit functions "cust1 cust2 cust3" for custom functions 7 8 and 9.
The distortion function is in "geomfunc".
cam is player eye position, to make F5 model viewing easy,
you don't have to use this in the functions.


NOTES:
P is gl_Vertex.
p is P.xyz-eye.
dpos is velocity (jittery at the moment, not sure why).

*/

#include "uniforms.glsl"
#include "functionlibs.glsl"

const float E = 2.718281828459045;
const float PI= 3.14159265359;
vec3 dir=playerLookVector;
//CUSTOM WARP FUNCTIONS
//            pos | velocity|campos  |headpos |dist   | variable|			pos xyz		  |time   |	world pos		|
vec3 cust1(vec3 p,vec3 vel,vec3 cam,vec3 eye,float d, float J, float x,float y,float z,float t,float X,float Y,float Z){

p=mat3(gbufferModelView)*p;
p.z-=d/1.1;	
p=mat3(gbufferModelViewInverse)*p;

return p;
}

vec4 rot4(vec4 p,vec4 q){
return(qmul(qmul(q,p),-q));

}
vec3 torusify(vec3 p,vec3 cam,float J){
float K=J/2;
p.y=tanh((p.y-cam.y)/K)*K;
p.y-=K;

p.xy=vec2(-sin(p.x*PI/J)*p.y,cos(p.x*PI/J)*p.y)+vec2(0,K);
p.y+=K;
p.zy=vec2(sin(p.z*PI/J)*p.y,cos(p.z*PI/J)*p.y)-vec2(0,K);
return p;
}
vec3 camtor(vec3 cam,vec3 vx,float J){
return vx;
}

vec3 cust2(vec3 p,vec3 vel,vec3 cam,vec3 eye,float d, float J, float x,float y,float z,float t,float X,float Y,float Z){
p=torusify(p+cam,cam,J)-torusify(cam,cam,J);

vec3 vx=normalize(torusify(cam+vec3(0.01,0,0),cam,J)-torusify(cam,cam,J));
vec3 vy=normalize(torusify(cam+vec3(0,0.01,0),cam,J)-torusify(cam,cam,J));
vec3 vz=normalize(torusify(cam+vec3(0,0,0.01),cam,J)-torusify(cam,cam,J));
mat3 dirc=mat3(vx,vy,vz);
p=inverse(dirc)*p;
return p;
}
  
vec3 cust3(vec3 p,vec3 vel,vec3 cam,vec3 eye,float d, float J, float x,float y,float z,float t,float X,float Y,float Z){
float a=(sin(t/6)*d)/J;

mat3 NIL = mat3(
cos(a),0,-sin(a),
0,1,0,
sin(a),0,cos(a));

return p*NIL;
}


#define MODE 0 // [0 1 2 3 4 5 6 7 8 9]
#define J 16 // [1 2 4 8 16 32 64 128 256 512]

#define f5_distance 1 // [1 2 3 4 5 6 7 8 9 10]


//this is the function that warps space
vec4 geomfunc(vec4 P){
//basic variables
	vec3 cam=eyePosition;
	vec3 eye=relativeEyePosition;
	vec3 p=P.xyz+eye;
	
	vec3 dpos=(cameraPosition-previousCameraPosition)/frameTime;
	float x=p.x,y=p.y,z=p.z,w=gl_Vertex.w,t=(frameTimeCounter);
	float X=x+cameraPosition.x,Y=y+cameraPosition.y,Z=z+cameraPosition.z;
	float d=length(p.xyz)/J;
//Solv geodesic approximation matrix that I found myself.
	vec2 o =rot(vec2(J,0),frameTimeCounter);

mat3 SOLV=mat3(
	pow(2,-y/J),		0,			0,
	x/J,			1,			-z/J,
	0,				0,			pow(2,y/J));


switch (MODE){

	case 0:
	p=inv(p,vec3(o.y,0,o.x));;
	break;
	
	case 1:
	p=inv(p,vec3(o.x,o.y,0));;
	break;
	
	case 2: 
	p=inv(p,vec3(0,o.x,o.y));;
	break;
	
	case 3:
	p+=dpos*d/J;
	break;
	
	case 4:
	p=inv(p,vec3(0,J,0));;
	break;
	
	case 5:
	p=inv(p,vec3(0,-J,0));;
	break;
	
	case 6:
	p=p*SOLV;;
	break;
	
	//custom 1
	case 7:
	p=cust1(p,dpos,cam,eye,length(p.xyz),J,x,y,z,t,X,Y,Z);
	break;

	//custom 2
	case 8:
	p=cust2(p,dpos,cam,eye,length(p.xyz),J,x,y,z,t,X,Y,Z);
	break;
	
	//custom 3
	case 9:
	p=cust3(p,dpos,cam,eye,length(p.xyz),J,x,y,z,t,X,Y,Z);
	break;

default:
p=p;
break;
}


return vec4(p-(eye*f5_distance),gl_Vertex.w);
}
/*
vec3 cust1(vec3 p,vec3 velocity,vec3 cam,vec3 eye,float d, float J, float x,float y,float z,float t,float X,float Y,float Z){
p=mat3(gbufferModelView)*p;
p.z-=d/1.1;
p=mat3(gbufferModelViewInverse)*p;

return p;
}
*/