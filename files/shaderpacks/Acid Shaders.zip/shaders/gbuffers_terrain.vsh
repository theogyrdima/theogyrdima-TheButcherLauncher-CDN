#version 120
#include "common.glsl"





varying vec4 color;
varying vec4 texcoord;
varying vec4 lmcoord;


vec2 rot(float a, float A, float B){
return vec2((cos(a)*A)+(sin(a)*B),(-sin(a)*A)+(cos(a)*B));
}
void main()
{
	vec4 p = gl_ModelViewMatrix * gl_Vertex;
	

		p = gbufferModelViewInverse * p;

	
p = geomfunc(p);

		p = gbufferModelView * p;

	
	gl_Position = gl_ProjectionMatrix * p;
	
	
	gl_FogFragCoord = 1;
	
	
	texcoord = gl_TextureMatrix[0] * gl_MultiTexCoord0;
	
	color = gl_Color;
	
	lmcoord = gl_TextureMatrix[1] * gl_MultiTexCoord1;
}