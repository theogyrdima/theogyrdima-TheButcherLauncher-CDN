uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferPreviousModelView;
uniform mat4 gbufferPreviousProjection;
uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;

uniform vec3 cameraPosition;
uniform vec3 cameraPositionFract;
uniform vec3 cameraPositionInt;
uniform vec3 cameraOffset;
uniform vec3 playerLookVector;
uniform vec3 upPosition;
uniform vec3 previousCameraPosition;
uniform vec3 previousCameraPositionFract;
uniform vec3 previousCameraPositionInt;
uniform vec3 relativeEyePosition;
uniform float eyeAltitude;

uniform vec3 chunkOffset;  


uniform float frameTime;
uniform float frameTimeCounter;
uniform int frameCounter;
uniform float viewHeight;
uniform float viewWidth;







uniform vec3 eyePosition;



uniform vec3 cameraSmooth;
